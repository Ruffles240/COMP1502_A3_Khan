package mru.tsc.application;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import mru.tsc.controller.Controller;
import mru.tsc.exceptions.IncompatiblePlayers;
import mru.tsc.exceptions.InvalidNegative;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.fxml.*;
import javafx.beans.value.ChangeListener;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.util.*;
import mru.tsc.exceptions.IncompatiblePlayers;
import mru.tsc.exceptions.InvalidNegative;
import mru.tsc.model.Animal;
import mru.tsc.model.BoardGame;
import mru.tsc.model.Figure;
import mru.tsc.model.Puzzle;
import mru.tsc.model.Toy;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.TextInputControl;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.ChoiceBoxListCell;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;




/**
 * This method finds the view file and runs it
 * 
 * 
 * 
 * 
 */

public class Main extends Application {
	
	@Override
	public void start(Stage primaryStage) throws Exception {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/TCC.fxml"));
        Parent root = loader.load();
        
      
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        
        
        primaryStage.show();
        
       
        
    }
	
	

	
	 /**
	  * THis method launches the application.
	  * @param args
	  * @throws IOException
	  * @throws InvalidNegative
	  * @throws IncompatiblePlayers
	  */
	public static void main(String[] args) throws IOException, InvalidNegative, IncompatiblePlayers {
		
		
		launch(args);
		
		 
}
	
	
}
