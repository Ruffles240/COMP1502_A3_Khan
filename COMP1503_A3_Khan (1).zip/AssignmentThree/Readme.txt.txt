Author: Raphael Khan
Title: Toy Store GUI