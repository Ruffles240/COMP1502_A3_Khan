package mru.tsc.exceptions;
/**
 * 
 * This class creates a custom exception for the BoardGame class.
 * 
 *
 */


public class InvalidNegative extends Exception {
	
	
	/**
	 * This constructs the Exception
	 * 
	 */
	public InvalidNegative(String message) {
	
			super(message);
			
	}
}
