package mru.tsc.controller;
	

import java.io.*;
import java.net.URL;
import java.text.DateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import javafx.fxml.*;
import javafx.beans.value.ChangeListener;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.util.*;
import mru.tsc.exceptions.IncompatiblePlayers;
import mru.tsc.exceptions.InvalidNegative;
import mru.tsc.model.Animal;
import mru.tsc.model.BoardGame;
import mru.tsc.model.Figure;
import mru.tsc.model.Puzzle;
import mru.tsc.model.Toy;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.control.TextInputControl;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.ChoiceBoxListCell;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


/**
 * This class controls the application.
 * 
 * 
 */


public class Controller  {
	
	
	//THis is my logger
	  private static final Logger logger = Logger.getLogger(Controller.class.getName());
	//These are all the different JavaFX InjectableFields
	
	@FXML
	public Button exitBtn;
	@FXML
	public  TextField nameInput;
	@FXML
	public  Button clrBtn;
	@FXML
	public TextField SNInput;
	@FXML
	public Label dd;
	@FXML
	public ListView<String> searchResults;
	@FXML
	public Button srchBTN;
	@FXML
	public Button purchaseBTN;
	@FXML
	static Tab searchTab;
	@FXML
	Tab recommendationTab;
	@FXML
	public ListView<String> removeOptions; 
	@FXML
	public TextField removeSN;
	@FXML
	public Button searchRmvBtn;
	@FXML
	public TextField addAnimal;
	@FXML
	public Button removeBtn;
	@FXML
	public Tab removeTab;
	@FXML
	public Tab addTab;
	@FXML
	public ChoiceBox addCat;
	@FXML
	public TextField addFigure;
	
	@FXML
	public RadioButton SNRadio;
	@FXML
	public RadioButton nameRadio;
	@FXML
	public RadioButton typeRadio;
	@FXML
	public Button saveBtn;
	@FXML
	public ChoiceBox searchCat;
	@FXML
	public TextField addPuzzle; 
	@FXML
	public TextField minPlay;
	@FXML
	public TextField maxPlay;
	@FXML
	public TextField makers;
	@FXML
	public TextField addName;
	@FXML
	public TextField addSN;
	@FXML
	public TextField addBrand;
	@FXML
	public TextField addPrice;
	@FXML
	public TextField addAvailable;
	@FXML
	public TextField addAge;
	@FXML
	public TextField recAge;
	@FXML
	public TextField recMin;
	@FXML
	public TextField recMax;
	@FXML
	public ChoiceBox recCat;
	@FXML
	public RadioButton ageOpt;
	@FXML
	public RadioButton typeRec;
	@FXML
	public RadioButton priceRec;
	@FXML
	public ListView<String> recList;
	@FXML
	public Button recPurch;
	
	
	// This field holds the ArrayList that is being updated and done by the file.
	public ArrayList<Toy> toyCatalogue = new ArrayList<Toy>();
	
	
	
	
	
	
	/**
	 * This method defines and details the application.
	 * @throws IOException throw this if the file cannot be found
	 * @throws InvalidNegative throw this if an object has invalid negative values
	 * @throws IncompatiblePlayers throw this if there is a minimum greater than a maximum.
	 */
   
	public Controller() throws IOException, InvalidNegative, IncompatiblePlayers, FileNotFoundException {
				
			 File toys = new File("src/toys.txt");
			 if( toys.exists()){
			 Scanner toyList= new Scanner(toys);
			 
			 toySorter(toyList);
			toyList.close();		
			}
			 
			 else {	 
				 popupWindow("Sorry, we cannot find our catalogue at this moment.");
				 System.exit(0);
			 }
			 
		
	}
	
	/**
	 * This initializes several FXML fields, inputs my listeners and populates my ChoiceBoxes, as well as calls my logger method
	 * @throws IOException 
	 * @throws SecurityException 
	 */
	@FXML
	public void initialize() throws SecurityException, IOException, FileNotFoundException {
		
		populateChoiceBox(recCat);
		populateChoiceBox(addCat);
		populateChoiceBox(searchCat);
		newToyListener();
		onlyNumeric(addSN,true);
		onlyNumeric(addPrice, false);
		onlyNumeric(addAvailable,true);
		onlyNumeric(minPlay,true);
		onlyNumeric(maxPlay, true);
		onlyNumeric(SNInput,true);
		onlyNumeric(addAge,true);
		onlyNumeric(removeSN,true );
		onlyNumeric(recAge, true);
		onlyNumeric(recMin, false);
		onlyNumeric(recMax, false);
		createLogger();

		

		
	}
	
	/**
	 * 
	 * This creates and handles my logger
	 * @throws SecurityException this indicates a security violation
	 * @throws IOException this handles any exception in which files are mishandled.
	 */
	
	public void createLogger() throws SecurityException, IOException {
		LogManager.getLogManager().reset();
		logger.setLevel(Level.ALL);
		
		FileHandler fh = new FileHandler("Toy Store Company Log.log", true); // Toy Store Company Log is the name of the file
		fh.setFormatter(new SimpleFormatter());
	    fh.setLevel(Level.ALL);
	    logger.addHandler(fh);
		
		
		LocalDateTime now = LocalDateTime.now();
	    logger.finest("[" + now + "] Everything worked very well this run");
	    logger.finer("[" + now + "] Everything worked well");
	    logger.fine("[" + now + "] There does not seem anything wrong.");
		 logger.info("[" + now + "]There may be something wrong, please ensure all inputs are validate.");
		    logger.warning("[" + now + "]We have a problem, it seems your date is not running correctly");
		    logger.severe("[" + now + "]We have encountered a severe error, program cannot run until fixed");
		    
		   
		
	}
	
	
	
	/**
	 * This method sorts the file into an ArrayList
	 * @param toyList, this scanner has all the text from the file
	 * @throws InvalidNegative This exception throws in case of values that should not be negative
	 * 
	 */
	public  void toySorter(Scanner toyList) throws InvalidNegative, IncompatiblePlayers {
		
		
		try {
		while(toyList.hasNextLine()) {
		String nextToy =toyList.nextLine();
		int toyNumber = (nextToy.charAt(0));
		toyNumber-=48;	
		if(toyNumber>=0&&toyNumber<=1) {
			Figure toy= new Figure(nextToy);
			toyCatalogue.add(toy);
		}
		
		else if(toyNumber>=2&&toyNumber<=3) {
			Animal toy= new Animal(nextToy);
			toyCatalogue.add(toy);
		}
		
		else if(toyNumber>=4&&toyNumber<=6) {
			Puzzle toy= new Puzzle(nextToy);
			toyCatalogue.add(toy);
			
		}
		
		else if(toyNumber>=7&&toyNumber<=9) {
			try {
			BoardGame toy = new BoardGame(nextToy);
			toyCatalogue.add(toy);}
			
			catch(IncompatiblePlayers f) {
				
				popupWindow("I'm sorry, it seems like one of our board game entries is invalid.");
			}
		}
		
		}}
		
		catch(InvalidNegative e) {
			
			popupWindow("I'm sorry, it seems our database has an incorrect entry, please double check to make sure everything is working as intended.");
		}
		
		
	}
	
/** This controls the reset button on the Search Tab
 * 
 * @param e this is a button event
 */
	public void resetSearch(ActionEvent e) {

		searchResults.getItems().clear();;
        nameInput.setText("");
        SNInput.setText("");	
	}
	/** This controls the clear button on the Search Tab
	 * 
	 * @param e this is a button event
	 */
	public void clrSearch(ActionEvent e) {

        nameInput.setText("");
        SNInput.setText("");
	            		
	}
	
	/** This controls the Search button on the Search Tab
	 * 
	 * @param e this is a button event
	 */
	public void search(ActionEvent e) {
		String name= nameInput.getText().toUpperCase();
		String SN = SNInput.getText();
		searchResults.getItems().clear();
		
		if(SNRadio.isSelected()){
			
			boolean checkSN= SNChecker(SN);
			if(checkSN==true) {
			for(Toy a: toyCatalogue) {
				if(a.getSN().equals(SN)) {
					    searchResults.getItems().add(a.toString());
				}}
		}
			else {
				popupWindow("Sorry, this is not a valid SIN, please use this format '0000000000')");
				SNInput.clear();
			}
		}
		if(nameRadio.isSelected()) {
			for(Toy b: toyCatalogue) {		
				if(b.getName().toUpperCase().contains(name)) {
					searchResults.getItems().add(b.toString());
				}
		}}
		if(typeRadio.isSelected()) {
			String category = searchCat.getSelectionModel().getSelectedItem().toString();
			for(Toy c: toyCatalogue) {	
				if(category.toUpperCase().contains(c.getCategory().toUpperCase())) {
					searchResults.getItems().add(c.toString());
				}
		}}
			if((typeRadio.isSelected()||nameRadio.isSelected()||SNRadio.isSelected())==false) {
				popupWindow("Please select one of the search types to use this function");
			}
	}
	/** This method ensures that you are incapable of inputting data without selecting the required field you are using to search.
	 * 
	 * @param e this is a button event
	 */
	
public void searchRadio(ActionEvent e) {
		if( SNRadio.isSelected()){
			SNInput.setDisable(false);
			nameInput.setDisable(true);
			searchCat.setDisable(true);
		}
		if( nameRadio.isSelected()){
			SNInput.setDisable(true);
			nameInput.setDisable(false);
			searchCat.setDisable(true);

		}
		if(typeRadio.isSelected()) {
			SNInput.setDisable(true);
			nameInput.setDisable(true);
			searchCat.setDisable(false);
		}
	}
/**
 * This method allows people to purchase a toy they have searched
 * @param e This is a button event
 * @throws FileNotFoundException throw this exception if the file cannot be found
 */



public void purchase(ActionEvent e) throws FileNotFoundException {
	ObservableList<String> selectedToy= searchResults.getSelectionModel().getSelectedItems();
	
	for(Toy a:toyCatalogue) {
		if(selectedToy.toString().contains(a.toString())) {
			a.setAvailable(Integer.toString(a.getAvailable()-1));
			saveStatus();
			popupWindow(a.toString() + "\n Thank you for your purchase");
			searchResults.getItems().clear();
			search(e);
			break;
		}
			
	}
	
	if((typeRadio.isSelected()||nameRadio.isSelected()||SNRadio.isSelected())==false) {
		popupWindow("Please select one of the search types and then search and select a toy to use this function");
	}
	
	
}


/**
 * This method controls and initiates all popup windows that occur
 * @param input This is the text you wish to be displayed
 */


public void popupWindow(String input) {
	// TODO Auto-generated method stub
	Stage newWindow = new Stage();
	newWindow.setTitle("New Scene");
	//Create view in Java
	Label message = new Label(input);
	Button button = new Button("OK");
	button.setOnAction(event -> {newWindow.close();
	    //handle button press
	});
	VBox container = new VBox(message, button);
	//Style container
	container.setSpacing(15);
	container.setPadding(new Insets(25));
	container.setAlignment(Pos.CENTER);
	//Set view in window
	newWindow.setScene(new Scene(container));
	//Launch
	newWindow.show();
}

/**
 * This method checks if SN's are valid or not.
 * @param SN this is the SN to be checked.
 * @return this returns if the SN is valid or not
 * 
 */


public static boolean SNChecker(String SN) {

			if(SN.length()==10) {

				for(char a:SN.toCharArray()) {
					if( Character.isDigit(a)==true){
						continue;
	
					}
					else {
						
								return false;
					}
				}
				
				}

				else {
					
						return false;
				}
			return true;

	}


/**
 * This is a Choice Box listener I added to the category field to ensure that I know what category is clicked when it is clicked.
 */
public void newToyListener() {
	
	addCat.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
	    if (newValue != null) {
	    		chooseAddCat(newValue.toString());}});
	
}
/**
 * This method populates my Choice Boxes
 */

public void populateChoiceBox(ChoiceBox chooseCat) {
	chooseCat.getItems().add("Figure");
	chooseCat.getItems().add("Animal");
	chooseCat.getItems().add("Board Game");
	chooseCat.getItems().add("Puzzle");
	
	
}


/**
 * This method attaches a listener to various textfields, ensuring that invalid inputs cannot be entered
 *
 * @param numericField the TextField to be listened and edited
 * @param This boolean checks whether to allow decimal numbers
 */



public void onlyNumeric(TextField numericField, boolean checkInt) {
	if(checkInt==true) {
	numericField.textProperty().addListener((observable, oldValue, newValue) -> {
	    if (!newValue.matches("\\d*")) {
	        numericField.setText(newValue.replaceAll("[^\\d]", ""));
	    }
	});}
	if(checkInt==false) {
	
	numericField.textProperty().addListener((ov, oldValue, newValue) -> {
        if (numericField.getText().length() > 5) {
            String s = numericField.getText().substring(0, 5);
            numericField.setText(s);
        }
        if (!newValue.matches("\\d*([\\.]\\d*)?")) {
        	numericField.setText(newValue.replaceAll("[^\\d*([\\.]\\d*)?]", ""));
        }
    });}
	
	
	
}

/**
 * This method enables/disables fields of input in the add tab based on the category you chose. It also attaches a listener to make sure you cannot enter incorrect inputs to the Category.
 * @param cat this is the text in the category chosen
 */
public void chooseAddCat(String cat) {
	
	addName.setDisable(false);
	
	addSN.setDisable(false);
	
	addBrand.setDisable(false);
	
	addPrice.setDisable(false);
	
	addAvailable.setDisable(false);
	
	addAge.setDisable(false);

	
	
	
	switch(cat.charAt(0)){
	
	
	case 'F':
		addSN.clear();
		addFigure.setDisable(false);
		addAnimal.setDisable(true);
		addPuzzle.setDisable(true);
		minPlay.setDisable(true);
		maxPlay.setDisable(true);
		makers.setDisable(true);
		
		inputListener("aAdDhH", addFigure);
		break;
	case 'A':
		addSN.clear();
		addFigure.setDisable(true);
		addAnimal.setDisable(false);
		addPuzzle.setDisable(true);
		minPlay.setDisable(true);
		maxPlay.setDisable(true);
		makers.setDisable(true);
	
		inputListener("sSmMlL", addAnimal);
	
		
		break;
	case 'P':
		addSN.clear();
		addFigure.setDisable(true);
		addAnimal.setDisable(true);
		addPuzzle.setDisable(false);
		minPlay.setDisable(true);
		maxPlay.setDisable(true);
		makers.setDisable(true);

		inputListener("MCLTR", addPuzzle);
		break;
	case 'B':
		addSN.clear();
		addFigure.setDisable(true);
		addAnimal.setDisable(true);
		addPuzzle.setDisable(true);
		minPlay.setDisable(false);
		maxPlay.setDisable(false);
		makers.setDisable(false);

		break;
	}
	
	
	
	
}




/**
 * This method attaches a listener to the different inputs in the fields specific to the subclasses of Toy, ensuring invalid inputs are incapable of being entered.
 * @param allowedCharacters
 * @param input
 */

public void inputListener(String allowedCharacters, TextField input) {
    input.textProperty().addListener((observable, oldValue, newValue) -> {
        if (newValue.length() == 1 && !allowedCharacters.contains(newValue)) {
            input.setText(oldValue);
        }
    });
    input.textProperty().addListener((observable, oldValue, newValue) -> {
        if (newValue.length() > 1) {
            input.setText(newValue.substring(0, 1));
        }
    });
}


/**
 * THis method handles the remove button and removes toys from the catalogue.
 * @param e
 * @throws FileNotFoundException
 */

public void handleRemoveBtn(ActionEvent e) throws FileNotFoundException {
	

    Iterator<Toy> iterator= toyCatalogue.iterator();
	
    if(removeOptions.getSelectionModel().getSelectedItem()!=null) {
    
    String selectedOption = removeOptions.getSelectionModel().getSelectedItem();
    
    while (iterator.hasNext()) {
    	  Toy a = iterator.next();
    	  if (selectedOption.contains(a.toString())) {
    	    iterator.remove();
    	    popupWindow("This item was removed.");
    	    removeOptions.getItems().clear();
    	    
    		saveStatus();
    	    
    	  }
    	}}
    else {
    	
    	popupWindow("You haven't selected a toy");
    }	
}

/**
 * This saves the application, it is attached to every single button that alters the status of the catalogue.
 * @throws FileNotFoundException
 */


public void saveStatus() throws FileNotFoundException {
	
	PrintWriter toys = new PrintWriter("src/toys.txt");
	for(Toy d:toyCatalogue) {
		toys.println(d.saveToy());
	}
	
	toys.close();
	
}
/**
 * This button adds the toy after taking in all the inputs, giving the user errors if there is an issue with their input.
 * @param e
 * @throws FileNotFoundException if the file cannot be found
 * @throws InvalidNegative if there is an invalid negative input for the toy
 * @throws IncompatiblePlayers if there is an invalid player minimum and maximum
 */



public void addToy(ActionEvent e) throws FileNotFoundException, InvalidNegative, IncompatiblePlayers {
	boolean validInput=true;
	char category =addCat.getSelectionModel().selectedItemProperty().getValue().toString().charAt(0);
	
	if(SNChecker(addSN.getText())){
		for(Toy A:toyCatalogue) {
			if(A.getSN().equals(addSN.getText())) {
				popupWindow("Oops, looks like this SN is taken, you need a valid one that is not taken");
				validInput=false;
				break;
			}
		}
		
	}
	
	else {
		popupWindow("that is not a valid SN. use this format 0000000000");
		addSN.clear();
		return;
	}
	if(addSN.getText().length()==0||addName.getText().length()==0||
			addAge.getText().length()==0||addBrand.getText().length()==0||
			addPrice.getText().length()==0||addAvailable.getText().length()==0 ){
		validInput=false;
		popupWindow("Missing required Fields");
		return;
	}
	
	
	if(validInput==true) {
		try {
		switch(category) {
		
		case 'F':
			
			if(addFigure.getText().length()!=1) {
				popupWindow("Sorry, you are missing a required field");
				break;
				
			}
			
			if(addSN.getText().charAt(0)!=('0')&&addSN.getText().charAt(0)!=('1')) {
				popupWindow("Your SN starts with the wrong digit, Figures must begin with a 0 or a 1.");
				break;
				
			}
			else {
				try{String figureEntry= addSN.getText()+";"+addName.getText()+";"+addBrand.getText()+";"+addPrice.getText()+";"+addAvailable.getText()+";"+addAge.getText()+";"+addFigure.getText().charAt(0);
				
				Figure addedFigure= new Figure(figureEntry);
				toyCatalogue.add(addedFigure);
				saveStatus();
				popupWindow("This has been added: "+ addedFigure.toString());
				
				}
				catch(InvalidNegative l) {
					popupWindow("Sorry, you cannot have negative numbers");
					break;
					
				}
				
				
				break;}
		case 'A':
			if(addAnimal.getText().length()!=1) {
				popupWindow("Sorry, you are missing a required field");
			break;
			}
			
			if(addSN.getText().charAt(0)!=('2')&&addSN.getText().charAt(0)!=('3')) {
				
				
				
				popupWindow("Your SN starts with the wrong digit, Animals must begin with a 2 or a 3.");	
				break;
			}
			
			
			else {
				try{String animalEntry= addSN.getText()+";"+addName.getText()+";"+addBrand.getText()+";"+addPrice.getText()+";"+addAvailable.getText()+";"+addAge.getText()+";"+addAnimal.getText().charAt(0);
				Animal addedAnimal= new Animal(animalEntry);
				toyCatalogue.add(addedAnimal);
				popupWindow("This has been added: "+ addedAnimal.toString());
				saveStatus();
				
				}
				catch(InvalidNegative L) {
					popupWindow("Sorry, you cannot have negative numbers");
					
				}
				break;}
		
		case 'P':
			if(addPuzzle.getText().length()!=1) {
				popupWindow("Sorry, you are missing a required field");
				break;
			}
			
				if(addSN.getText().charAt(0)!=('4')&&addSN.getText().charAt(0)!=('5')&&addSN.getText().charAt(0)!=('6')) {
				
					popupWindow("Your SN starts with the wrong digit, Animals must begin with a 4,5 or a 6.");
					break;
				}
			
			else {
				String puzzleEntry= addSN.getText()+";"+addName.getText()+";"+addBrand.getText()+";"+addPrice.getText()+";"+addAvailable.getText()+";"+addAge.getText()+";"+addPuzzle.getText().charAt(0);
				
				Puzzle addedPuzzle= new Puzzle(puzzleEntry);
				toyCatalogue.add(addedPuzzle);
				popupWindow("This has been added: "+ addedPuzzle.toString());
				saveStatus();
				
				break;}
			
		
		case 'B':
			if(minPlay.getText().length()==0||maxPlay.getText().length()==0||makers.getText().length()==0) {
			popupWindow("Sorry, you are missing a required field");
				break;
				}
			if(addSN.getText().charAt(0)!=('7')&&addSN.getText().charAt(0)!=('8')&&addSN.getText().charAt(0)!=('9')) {
				
				popupWindow("Your SN starts with the wrong digit, Animals must begin with a 7,8 or a 9.");
				break;}
			
			else {
				try {
				String bgEntry= addSN.getText()+";"+addName.getText()+";"+addBrand.getText()+";"+addPrice.getText()+";"+addAvailable.getText()+";"+addAge.getText()+";"+minPlay.getText()+"-"+maxPlay.getText()+";"+makers;
				
				BoardGame addedGame= new BoardGame(bgEntry);
				
				toyCatalogue.add(addedGame);
				popupWindow("This has been added: "+ addedGame.toString());
				saveStatus();
				}
				
				catch(IncompatiblePlayers y) {
					popupWindow("Sorry, the minimum players cannot be greater than the maximum");
					
				}
				
				break;}
		}	
	}
		catch(InvalidNegative x) {
			popupWindow("Sorry, prices and ages cannot be negative");
			
			
		}
	
	}
	
}


/**
 * This searches for the item to be removed.
 * @param e this is a button press
 */
public void handleRmvSrchBtn(ActionEvent e) {
	boolean toyFound=false;
	removeOptions.getItems().clear();
	String SN= removeSN.getText();
	
	boolean checkSN= SNChecker(SN);
	
	if(checkSN==true) {
	for(Toy a: toyCatalogue) {
		
		if(a.getSN().equals(SN)) {
			
			  
			    removeOptions.getItems().add(a.toString());
			    toyFound= true;
			    break;
			
		}
		else {
			continue;
		}
	
	}
	if(toyFound==false) {
		popupWindow("Sorry, we could not find your toy");
		
	}
	
	
}
	else {
		popupWindow("Sorry, this is not a valid SIN, please use this format '0000000000')");
		removeSN.clear();
	}
	
	
}

/**
 * This method is attached to all the radio buttons in the recommendation tab. Anytime one is selected, the corresponding field is enabled.
 */

public void recRadio() {
	if(priceRec.isSelected()) {
		recMin.setDisable(false);
		recMax.setDisable(false);
		
	}
	if(ageOpt.isSelected()){
		recAge.setDisable(false);
		
		
	}
	if(typeRec.isSelected()) {
		recCat.setDisable(false);
		
		
	}
	if(priceRec.isSelected()==false) {
		recMin.setDisable(true);
		recMax.setDisable(true);
		
	}
	if(ageOpt.isSelected()==false){
		recAge.setDisable(true);
	
		
	}
	if(typeRec.isSelected()==false) {
		recCat.setDisable(true);
	
	}
}

/**
 * THis handles the search for the recommendation button
 * @param e
 */

public void handleRecSearch(ActionEvent e) {
	recList.getItems().clear();
	
	if((ageOpt.isSelected()&&(typeRec.isSelected()||priceRec.isSelected()))||
			((typeRec.isSelected()&&(ageOpt.isSelected()||priceRec.isSelected())))||
			((priceRec.isSelected()&&(ageOpt.isSelected()||typeRec.isSelected())))
			
			
			) {
	boolean checkOptions=true;
	
	ArrayList<Toy> recs= new ArrayList<Toy>();
	for(Toy K:toyCatalogue) {
		recs.add(K);
		
	}
	
	
	
	if(ageOpt.isSelected()) {
		
		if(recAge.getText().length()!=0) {
			int age =Integer.parseInt(recAge.getText());
			Iterator<Toy> iterator =recs.iterator();
				while(iterator.hasNext()) {
					Toy B = iterator.next();
						if((B.getAge()>age)) {
						iterator.remove();
			
					}
		
			}
	
		}
			else {
		
		popupWindow("Sorry, please don't leave fields blank");
		checkOptions=false;
			}
		
		
	}
	
	
	if(priceRec.isSelected()) {

		
		
		if(recMin.getText().length()>0&&recMax.getText().length()>0) {
			
			
				double min= Double.parseDouble(recMin.getText());
					double max= Double.parseDouble(recMax.getText());
					
					if(min>max) {
						popupWindow("Sorry, please do not have your minimum price be greater than your maximum");
						
						return;
					}
					Iterator<Toy> iterator =recs.iterator();
						while(iterator.hasNext()) {
								Toy B = iterator.next(); {
										if((B.getPrice()<=min)||(B.getPrice()>=max)) {
											iterator.remove();
				
			}
			
		}}}
		
		else {
			checkOptions=false;
			popupWindow("Sorry, please don't leave fields blank");
		}
	}
	
	
	if(typeRec.isSelected()) {
		if(recCat.getValue()!=null) {
			String category= recCat.getValue().toString().toUpperCase();
			Iterator<Toy> iterator =recs.iterator();

			while(iterator.hasNext()) {
				Toy B = iterator.next(); 
				if(category.equals(B.getCategory())==false) {
					iterator.remove();
		}
					
				}
			
		}
		
		else {
			checkOptions=false;
			popupWindow("Sorry, please select a category option, or unselect the radio button");
		}
		
	}
	if(checkOptions==true) {
		
		for(Toy A:recs) {
			recList.getItems().add(A.toString());
			
		}
	}}
	
	
	else{
		
		popupWindow("Sorry, please choose at least two options");
		
	}
	
	}
		

/**
 * This handles purchasing the recommendation
 * @param e button press event.
 * @throws FileNotFoundException
 */
	public void handleRecPurch(ActionEvent e) throws FileNotFoundException {
		
		
			ObservableList<String> selectedToy= recList.getSelectionModel().getSelectedItems();
			
			for(Toy a:toyCatalogue) {
				if(selectedToy.toString().contains(a.toString())) {
					a.setAvailable(Integer.toString(a.getAvailable()-1));
					saveStatus();
					popupWindow(a.toString()+"\n Thank you for your purchase");
					recList.getItems().clear();
					handleRecSearch(e);
					break;
				}
					
			}
			
			
			
			
		}
	
	
	/**
	 * This method handles the exit button and saves all info
	 * @throws FileNotFoundException 
	 *@param e This is the action event.
	 */
	public void exitBtn(ActionEvent e) throws FileNotFoundException {
		saveStatus();
		System.exit(0);
		
	}
}





